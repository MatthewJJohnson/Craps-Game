#include "Equations.h"

int main(void)
{
	double balance = 0.0, wager = 0.0, add_or_subtract = 0.0, initial_bank_balance = 0.0;
	int validity = 0, die1 = 0, die2 = 0, dietotal = 0, point = 0, first_roll_result = 0, win_count = 0, loss_count = 0, play_again = 0, number_rolls = 1;

	srand((unsigned int)time(NULL));

	printf("'Craps!' Rules:\nA player rolls two dice. Each die has six faces. These faces contain 1, 2, 3, 4, 5, and 6 spots. After the dice have come to rest, the sum of the spots on the two upward faces is calculated. If the sum is 7 or 11 on the first throw, the player wins. If the sum is 2, 3, or 12 on the first throw (called 'craps'), the player loses (i.e. the 'house' wins). If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's 'point'. To win, you must continue rolling the dice until you 'make your point'. The player loses by rolling a 7 before making the point.");
	balance = get_bank_balance(); // user inputs bank balance
	initial_bank_balance = balance; //initial bank balance is set before any loops occur

	do
	{
		while (validity == 0)
		{
			wager = get_wager_amount();
			validity = check_wager_amount(wager, balance); //wager is ensured that balance is greater than wager
		}

		die1 = roll_die();
		die2 = roll_die();
		printf("Dice Roll: %u,%u\n", die1, die2);
		dietotal = calculate_sum_dice(die1, die2); // Games first roll has been played
		printf("The sum of your dice roll was %d\n", dietotal);
		point = dietotal;

		first_roll_result = is_win_loss_or_point(dietotal);
		add_or_subtract = first_roll_result;
		balance = adjust_bank_balance(balance, wager, add_or_subtract); // Balance is changed due to wager if a win or loss results
		chatter_messages(number_rolls, win_count, loss_count, balance);

		system("pause");

		if (first_roll_result == 1) // win counter +1
			win_count++;
		if (first_roll_result == 0) // loss counter +1
			loss_count++;
		else
		{
			while (first_roll_result == -1) //The user did not win or lose, so now a loop executes until they do so.
			{
				number_rolls += 1; // number of rolls increases by one
				die1 = roll_die();
				die2 = roll_die();
				printf("Dice Roll: %u,%u\n", die1, die2);
				dietotal = calculate_sum_dice(die1, die2); // The Nth roll of a game has been played
				printf("The sum of your dice roll was %d\n", dietotal);

				first_roll_result = is_point_loss_or_neither(dietotal, point);

				add_or_subtract = first_roll_result;
				balance = adjust_bank_balance(balance, wager, add_or_subtract); // Balance is changed due to wager if a win or loss results
				chatter_messages(number_rolls, win_count, loss_count, balance);

				system("pause");

				if (first_roll_result == 1) // win counter +1
					win_count++;
				if (first_roll_result == 0) // loss counter +1
					loss_count++;
			}
		}
		printf("Number of wins: %d\n", win_count);
		printf("Number of Losses: %d\n", loss_count);
		printf("Keep Playing? (Enter 1 for yes, 0 for no)");
		scanf("%d", &play_again); // user provides a true or false statement
		validity = 0;

	} while (play_again); // loop repeats if user provides a 1, a "true" statement
	return 0;
}