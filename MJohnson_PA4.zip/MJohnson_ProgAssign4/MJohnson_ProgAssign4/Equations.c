#include "Equations.h"

/*************************************************************
* Function: void print_game_rules(void)
* Description:  This function prints the game rules
* Input parameters:		--
* Returns:				--
*************************************************************/
void print_game_rules(void)
{
	printf("A player rolls two dice. Each die has six faces. These faces contain 1, 2, 3, 4, 5, and 6 spots. After the dice have come to rest, the sum of the spots on the two upward faces is calculated. If the sum is 7 or 11 on the first throw, the player wins. If the sum is 2, 3, or 12 on the first throw (called 'craps'), the player loses (i.e. the 'house' wins). If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's 'point'. To win, you must continue rolling the dice until you 'make your point'. The player loses by rolling a 7 before making the point.");
}

/*************************************************************
* Function: double get_bank_balance(void)
* Description:  This function recieves the intial bank balance from the user.
* Input parameters:		--
* Returns:				bank_balance
*************************************************************/
double get_bank_balance(void)
{
	double bank_balance = 0.0;
	printf("\n\nEnter your beginning bank balance:\n");
	scanf("%lf", &bank_balance);
	return bank_balance;
}

/*************************************************************
* Function: double get_wager_amount(void)
* Description:  This function recieves a wager from the user
* Input parameters:		--
* Returns:				wager_amount
*************************************************************/
double get_wager_amount(void)
{
	double wager_amount = 0.0;
	printf("What would you like to wager?\n");
	scanf("%lf", &wager_amount);
	return wager_amount;
}

/*************************************************************
* Function: int check_wager_amount(double wager_amount, double bank_balance)
* Description:  This function checks to see if the wager from the user is greater
* than the bank balance. If so (result = 1), the user must re-enter their wager.
* Input parameters:		wager_amount, bank_balance
* Returns:				result
*************************************************************/
int check_wager_amount(double wager_amount, double bank_balance)
{
	int result = 0;
	if (wager_amount > bank_balance)
	{
		result = 0;
		printf("You cannot wager more than you have.\n");
	}
	else
	{
		result = 1;
	}
	return result;
}

/*************************************************************
* Function: unsigned int roll_die(void)
* Description:  This function provides a random integer for each die roll. 
* Input parameters:		--
* Returns:				die
*************************************************************/
unsigned int roll_die(void)
{
	unsigned int die = 0;
	die = (rand() % 6) + 1;
	return die;
}

/*************************************************************
* Function: int calculate_sum_dice(int die1, int die2)
* Description:  This function provides calculates the sum of the dice.
* Input parameters:		die1,die2
* Returns:				sum
*************************************************************/
int calculate_sum_dice(int die1, int die2)
{
	int sum = 0;
	sum = die1 + die2;
	return sum;
}

/*************************************************************
* Function: int is_win_loss_or_point(int dietotal)
* Description:  This function determines if the user has won or lost given
* their most recent roll. 
* Input parameters:		dietotal
* Returns:				result
*************************************************************/
int is_win_loss_or_point(int dietotal)
{
	int result = 0;

	if ((dietotal == 7) || (dietotal == 11))
	{
		printf("You have rolled a 7 or an 11, meaning you won!\n");
		result = 1;
	}
	else if ((dietotal == 2) || (dietotal == 3) || (dietotal == 12))
	{
		printf("You have rolled a 2, 3, or 12, meaning you have lost!\n");
		result = 0;
	}
	else
	{
		printf("Your previous roll, %d, is now your point.\n", dietotal);
		result = -1;
	}
	return result;
}

/*************************************************************
* Function: int is_point_loss_or_neither(int dietotal, int point)
* Description:  This function determines if the user has won by
* matching their point, lost by rolling a 7, or neither(continuing).
* their most recent roll.
* Input parameters:		dietotal, point
* Returns:				result
*************************************************************/
int is_point_loss_or_neither(int dietotal, int point)
{
	if (dietotal == point)
	{
		printf("You matched your point, you won!\n");
		return 1;
	}
	else if (dietotal == 7)
	{
		printf("Your rolled a 7! You have lost!\n");
		return 0;
	}
	else
	{
		printf("You did not make your point, but you have not lost either. Your point is %d.\n", point);
		return -1;
	}
}

/*************************************************************
* Function: double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract)
* Description:  This function changes the balance of the bank due to the previous wager.
* if the user won, their bank is increased by their wager. If not, their bank is decreased
* by their wager.
* Input parameters:		bank_balance, wager_amount, add_or_subtract
* Returns:				new_balance
*************************************************************/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract)
{
	double new_balance = 0.0;

	if (add_or_subtract == 1)
	{
		new_balance = bank_balance + wager_amount;
		printf("Your New Balance is $%.2lf\n", new_balance);
	}
	else if (add_or_subtract == 0)
	{
		new_balance = bank_balance - wager_amount;
		printf("Balance: $%.2lf\n", new_balance);
	}
	else
	{
		new_balance = bank_balance;
		printf("Balance: $%.2lf\n", new_balance);
	}
	return new_balance;
}

/*************************************************************
* Function: void chatter_messages(int number_rolls, int win_count, int loss_count, double balance)
* Description:  This function emits chatter messages based on certain criteria. 
* After 6 in game rolls, the teller says that the user likes the game.
* After getting over 1000 as a balance, the teler reports the user has a wad of cash.
* After winning once, the teller asks if the user is cheating.
* After losing twice, the teller asks the user to hang in there.
* Input parameters:		bank_balance, wager_amount, add_or_subtract
* Returns:				new_balance
*************************************************************/
void chatter_messages(int number_rolls, int win_count, int loss_count, double balance)
{
	if (number_rolls > 6)
	{
		printf("(Teller says) Another roll? You must really like this game.\n");
	}
	if (balance > 1000)
	{
		printf("(Teller says) You have yourself a serious wad of cash.\n", balance);
	}
	if (win_count > 1)
	{
		printf("(Teller says) Congrats on those wins. Are you sure you aren't cheating?\n");
	}
	else if (loss_count > 2)
	{
		printf("(Teller says) You have lost a few but hang in there!");
	}
}